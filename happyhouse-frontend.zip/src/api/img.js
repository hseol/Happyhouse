// import { imgInstance } from "./index.js";

// const img = imgInstance();
// function saveImage(image, success, fail) {
//   img.post(`/file`, JSON.stringify(image)).then(success).catch(fail);
// }

// function getArticle(articleno, success, fail) {
//   img.get(`/file/${articleno}`).then(success).catch(fail);
// }

// function modifyArticle(article, success, fail) {
//   img
//     .put(`/file/${article.articleno}`, JSON.stringify(article))
//     .then(success)
//     .catch(fail);
// }

// function deleteArticle(articleno, success, fail) {
//   img.delete(`/file/${articleno}`).then(success).catch(fail);
// }

// export { listArticle, writeArticle, getArticle, modifyArticle, deleteArticle };
