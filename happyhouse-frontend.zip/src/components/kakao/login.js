const kakaoHeader = {
  Authorization: "d51b95e99868691ee5a5fe7c2bf85bde",
  "Content-type": "application/x-www-form-urlencoded;charset=utf-8",
};
const getKakaoToken = async (code) => {
  console.log("loginWithKakao");
  try {
    const data = {
      grant_type: "authorization_code",
      client_id: "059fc0b0941c9684fe53e7a198c3d420",
      redirect_uri: "http://localhost:8080/auth",
      code: code,
    };
    const queryString = Object.keys(data)
      .map((k) => encodeURIComponent(k) + "=" + encodeURIComponent(data[k]))
      .join("&");
    const result = await axios.post(
      "https://kauth.kakao.com/oauth/token",
      queryString,
      { headers: kakaoHeader }
    );
    console.log("카카오 토큰", result);
    return result;
  } catch (e) {
    return e;
  }
};
