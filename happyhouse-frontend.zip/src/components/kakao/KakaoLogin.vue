<template>
  <img
    class="kakao_btn"
    src="@/assets/kakao_login_medium_narrow.png"
    @click="loginKakaoBtn"
  />
</template>

<script>
export default {
  name: "KakaoLogin",
  methods: {
    loginKakaoBtn() {
      const params = {
        redirectUri: "http://localhost:8080/auth",
      };
      window.Kakao.Auth.authorize(params);
    },

    // kakaoLoginBtn() {
    //   window.Kakao.init("929551aadfc7f7f042a99f58cbd97041"); // Kakao Developers에서 요약 정보 -> JavaScript 키

    //   if (window.Kakao.Auth.getAccessToken()) {
    //     window.Kakao.API.request({
    //       url: "/v1/user/unlink",
    //       success: function (response) {
    //         console.log(response);
    //       },
    //       fail: function (error) {
    //         console.log(error);
    //       },
    //     });
    //     window.Kakao.Auth.setAccessToken(undefined);
    //   }

    //   window.Kakao.Auth.login({
    //     success: function () {
    //       window.Kakao.API.request({
    //         url: "/v2/user/me",
    //         data: {
    //           property_keys: ["kakao_account.email"],
    //         },
    //         success: async function (response) {
    //           console.log(response);
    //         },
    //         fail: function (error) {
    //           console.log(error);
    //         },
    //       });
    //     },
    //     fail: function (error) {
    //       console.log(error);
    //     },
    //   });
    // },
  },
};
</script>

<style scoped>
.test {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
div {
  width: 200px;
  height: 40px;
  background-color: #fdd101;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
</style>
