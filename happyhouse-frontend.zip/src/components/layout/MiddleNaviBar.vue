<template>
  <div id="footer">
    <b-container id="container" class="mt-2 p-2">
      <br />
    </b-container>
  </div>
</template>
<style scoped>
#container {
  height: 160px;
}
</style>
<script>
export default {};
</script>
