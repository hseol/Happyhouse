<template>
  <div>
    <b-row>
      <b-col>
        <b-card id="smallcard">
          <b-card-header
            id="card-header"
            bg-variant="light"
            header="일련번호:000"
            class="text-left"
          ></b-card-header>
          <b-card-body id="card-body">
            <b-row>
              <img
                src="@/assets/ddangsun.png"
                style="width: 160px; height: 80px"
              />
            </b-row>
            <br />
            <b-row>
              <b-card-text
                >아파트이름{{ house.apartmentName }}<br />
                층수 면적{{ house.floor }}{{ house.area }}<br />
                건축년도{{ house.buildYear }}<br />
                매매날짜{{ house.dealYear }}<br />
                매매가{{ house.recentPrice }}</b-card-text
              >
              <!-- <b-card-text>{{ house.dealMonth }}</b-card-text>
        <b-card-text>{{ house.dealDay }}</b-card-text>
        <b-card-text>매매가{{ house.recentPrice }}</b-card-text> -->
            </b-row>
          </b-card-body>
        </b-card>
      </b-col>
      <b-col>
        <div
          class="cardd"
          style="
            width: 220px;
            height: 330px;
            border-radius: 10px;
            border: 1px;
            background-color: #ffe49273;
          "
        >
          <div class="row" style="width: 220px">
            <div class="col-md-9" style="height: 39px">
              ${house.apartmentName}
            </div>
            <div class="col-md-3" style="height: 39px">하트</div>
          </div>

          <div class="row" style="height: 85px">아마도 사진</div>
          <div class="row" style="height: 171px">
            아파트이름 층수 평수 건축년도 계약일 가격
          </div>
        </div>
      </b-col>
    </b-row>
  </div>
</template>

<script>
//import houseStore from "@/store/modules/houseStore";
export default {
  data() {
    return {
      houses: [],
      house: [],
      message: "hi",
    };
  },
  created() {
    console.log(this.$store.state.houses);
  },
};
</script>

<style>
#cardd {
  width: 220px;
  height: 330px;
  padding: 0px;
}
#card-header {
  padding: 0px;
}
#card-body {
  padding: none;
  padding-bottom: 6rem;
}
</style>
