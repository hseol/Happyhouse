<!-- template>
  <b-avatar
    :src="require('../../../back/uploads/${file}')"
    size="6rem"
  ></b-avatar>-->

//
<script>
// export default {
//   data() {
//     return {
//       imagelist: [],
//     };
//   },
//   mounted() {
//     axios({
//       url: "http://localhost:9999/vue",
//       method: "POST",

//       data: this.$route.query.id,
//     })
//       .then((res) => {
//         this.userid = res.data.userid;
//         this.imagelist.push(this.$route.query.id + "-" + i + ".png");
//       })
//       .catch((err) => {
//         alert(err);
//       });
//   },
// };
// //
//
</script>

// // //
<style></style>
//
